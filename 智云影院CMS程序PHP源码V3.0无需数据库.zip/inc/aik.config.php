<?php
 $aik =  array (
  'sitename' => '刀客影院',
  'pcdomain' => 'http://cs.dkewl.cn/',
  'title' => '智云影院-在线免费观看最新好看的电影和电视剧',
  'keywords' => '智云影院,电视直播网站,苹果CMS程序,高清电影,云点播,免费看视频,最新电视剧,最新综艺节目,最新电影免费在线观看',
  'description' => '智云影院,热剧快播,最好看的剧情片尽在﻿智云影院,高清云影视免费为大家提供最新最全的免费电影，电视剧，综艺，动漫无广告在线云点播，以及电视直播',
  'icp' => '国ICP备18888888号',
  'foot' => '本站提供的最新电影和电视剧资源均系收集于各大视频网站,本站只提供web页面服务,并不提供影片资源存储,也不参与录制、上传</br>若本站收录的节目无意侵犯了贵司版权，请给网页底部邮箱地址来信,我们会及时处理和回复,谢谢。',
  'tongji' => '<script type="text/javascript" src="https://js.users.51.la/21354177.js"></script>',
  'youlian' => '<a target="blank" class="gobtn" href="https://www.dkewl.com">精品源码</a><a target="blank" class="gobtn" href="dh.php">导航大全</a></br></br><a target="blank" class="gobtn" href="https://www.dkewl.com">刀客源码网</a><a target="blank" class="gobtn" href="javascript:history.back()">返回上页</a>',
  'shouquan' => 'NzNiYmQwNGI2YjUxZWViODIzNDI2YzgwODBkMWI0YTQ2NDJmOQ==',
  'zhanwai' => 'http://23.224.101.30/api.php/provide/vod/from/lzm3u8/',
  'zhan1' => '<a href="?cid=6&page=1">动作片</a>
<a href="?cid=7&page=1">喜剧片</a>
<a href="?cid=8&page=1">爱情片</a>
<a href="?cid=9&page=1">科幻片</a>
<a href="?cid=10&page=1">恐怖片</a>
<a href="?cid=11&page=1">剧情片</a>
<a href="?cid=12&page=1">战争片</a>
<a href="?cid=13&page=1">国产剧</a>
<a href="?cid=14&page=1">香港剧</a>
<a href="?cid=15&page=1">韩国剧</a>
<a href="?cid=16&page=1">欧美剧</a>
<a href="?cid=20&page=1">记录片</a>
<a href="?cid=21&page=1">台湾剧</a>
<a href="?cid=22&page=1">日本剧</a>
<a href="?cid=23&page=1">海外剧</a>
<a href="?cid=24&page=1">泰国剧</a>
<a href="?cid=25&page=1">大陆综艺</a>
<a href="?cid=26&page=1">港台综艺</a>
<a href="?cid=27&page=1">日韩综艺</a>
<a href="?cid=28&page=1">欧美综艺</a>
<a href="?cid=29&page=1">国产动漫</a>
<a href="?cid=30&page=1">日韩动漫</a>
<a href="?cid=31&page=1">欧美动漫</a>
<a href="?cid=32&page=1">港台动漫</a>
<a href="?cid=33&page=1">海外动漫</a>
<a href="?cid=34&page=1">伦理片</a>
<a href="?cid=37&page=1">足球</a>
<a href="?cid=38&page=1">篮球</a>
<a href="?cid=39&page=1">网球</a>
<a href="?cid=40&page=1">斯诺克</a>
<a href="?cid=41&page=1">演员</a>
<a href="?cid=42&page=1">新闻资讯</a>
<a href="?cid=43&page=1">电影资讯</a>
<a href="?cid=44&page=1">娱乐新闻</a>
<a href="?cid=45&page=1">预告片</a>
<a href="?cid=46&page=1">短剧</a>',
  'zhanwai1' => 'https://api.wujinapi.me/api.php/provide/vod/',
  'zhan2' => '<a href="?cid=6&page=1">动作片</a>
<a href="?cid=7&page=1">喜剧片</a>
<a href="?cid=8&page=1">爱情片</a>
<a href="?cid=9&page=1">科幻片</a>
<a href="?cid=10&page=1">恐怖片</a>
<a href="?cid=11&page=1">剧情片</a>
<a href="?cid=12&page=1">战争片</a>
<a href="?cid=13&page=1">国产剧</a>
<a href="?cid=14&page=1">香港剧</a>
<a href="?cid=15&page=1">台湾剧</a>
<a href="?cid=16&page=1">美国剧</a>
<a href="?cid=21&page=1">纪录片</a>
<a href="?cid=22&page=1">韩国剧</a>
<a href="?cid=23&page=1">日本剧</a><a href="?cid=24&page=1">海外剧</a><a href="?cid=25&page=1">大陆综艺</a>
<a href="?cid=26&page=1">日韩综艺</a>
<a href="?cid=27&page=1">港台综艺</a>
<a href="?cid=28&page=1">欧美综艺</a>
<a href="?cid=29&page=1">国产动漫</a>
<a href="?cid=30&page=1">日韩动漫</a>
<a href="?cid=31&page=1">欧美动漫</a>
<a href="?cid=32&page=1">悬疑片</a>
<a href="?cid=33&page=1">动画片</a>
<a href="?cid=34&page=1">犯罪片</a>
<a href="?cid=35&page=1">奇幻片</a>
<a href="?cid=36&page=1">邵氏电影</a>
<a href="?cid=37&page=1">泰剧</a>
<a href="?cid=38&page=1">体育赛事</a>
<a href="?cid=40&page=1">影视解说</a>',
  'zhanwai2' => 'https://api.apibdzy.com/api.php/provide/vod/from/dbm3u8/',
  'zhan3' => '<a href="?cid=6&page=1">动作片</a>
<a href="?cid=7&page=1">喜剧片</a>
<a href="?cid=8&page=1">爱情片</a>
<a href="?cid=9&page=1">科幻片</a>
<a href="?cid=10&page=1">恐怖片</a>
<a href="?cid=11&page=1">剧情片</a>
<a href="?cid=12&page=1">战争片</a>
<a href="?cid=13&page=1">大陆剧</a>
<a href="?cid=14&page=1">港澳剧</a>
<a href="?cid=15&page=1">韩剧</a>
<a href="?cid=16&page=1">日剧</a>
<a href="?cid=17&page=1">纪录片</a>
<a href="?cid=18&page=1">犯罪片</a>
<a href="?cid=20&page=1">动画电影</a>
<a href="?cid=21&page=1">台湾剧</a>
<a href="?cid=22&page=1">欧美剧</a>
<a href="?cid=23&page=1">其他剧</a>
<a href="?cid=24&page=1">泰剧</a>
<a href="?cid=25&page=1">大陆综艺</a>
<a href="?cid=26&page=1">日韩综艺</a>
<a href="?cid=27&page=1">港台综艺</a>
<a href="?cid=28&page=1">欧美综艺</a>
<a href="?cid=29&page=1">国产动漫</a>
<a href="?cid=30&page=1">日韩动漫</a>
<a href="?cid=31&page=1">欧美动漫</a>
<a href="?cid=32&page=1">悬疑片</a>
<a href="?cid=33&page=1">邵氏电影</a>
<a href="?cid=37&page=1">电影资讯</a>
<a href="?cid=38&page=1">明星资讯</a>
<a href="?cid=39&page=1">预告</a>',
  'jiekou' => 'ck/index.php?url=',
  'admin_name' => 'admin',
  'admin_pass' => '3ceb0e9fb16f8673c35f707e8657124a',
  'admin_email' => 'admin@admin.com',
  'logo_dh' => '<img src="images/logo.png">',
  'logo_ss' => '<img id="imgsrc" src="images/sologo.png">',
  'movie_ad' => '<a href="https://www.dkewl.com" target="_blank"><img src="images/dc5c7986daef50c.gif" style="width:100%"></a>',
  'bofang_ad' => '<a href="https://www.dkewl.com" target="_blank"><img src="images/dc5c7986daef50c.gif" style="width:100%"></a>',
  'jiazai_ad' => '<a href="https://www.dkewl.com" target="_blank"><img src="images/jiazai.png" width="100%"></a>',
  'dongman_ad' => '公告：欢迎访问刀客影音！聚合全网影片，你想看的全都有！海量资源，想看啥就看啥！最新、最热、最全的影视大片，高清正版免费在线观看！更多精彩资源请下载官方APP或收藏官方发布页及关注官方微信公众号',
  'tishi_ad' => '<style> 
 .black_overlay{  display: none;  position: absolute;  top: 0%;  left: 0%;  width: 100%;  height: 100%;  background-color: black;  z-index:1001;  -moz-opacity: 0.8;  opacity:.80;  filter: alpha(opacity=80);  }  .white_content {  display: none;  position: absolute;  top: 25%;  left: 25%;  width: 50%;   height: auto; padding: 16px;  border: 16px solid orange;  background-color: white;  z-index:1002;  overflow: auto;  }  </style> 
<a href="javascript:void(0)" onclick="document.getElementById(\'light\').style.display=\'block\';document.getElementById(\'fade\').style.display=\'block\'"><p style="text-align:center;color: #fff;font-size: 10px;background: #6ED56C;padding:11px 8px;border-radius: 2px;">点击关注“智云影院”官方发布页，看电影更方便!</p></a>
<div id="light" class="white_content"> 
  <img src="images/qrcode.png" width="100%" height="100%">
    <a href="javascript:void(0)" onclick="document.getElementById(\'light\').style.display=\'none\';document.getElementById(\'fade\').style.display=\'none\'"> 
    <span class="rewards-popover-close" etap="rewards-close"></span></a></div> 
<div id="fade" class="black_overlay"> 
</div> ',
  'dbts' => '【点击选择剧集才会播放哦！】',
  'zfb_ad' => '<img src="images/zfb.png">',
  'wx_ad' => '<img src="images/wx.png">',
  'cebian1_ad' => '<a class="style01" href="http://wpa.qq.com/msgrd?v=3&uin=2248186422&site=qq&menu=yes" target="_blank"><strong>官方发布</strong><h2>更好的视频主题</h2><p>若视频未能播放出来，请点击播放框框内的 m3u8播放 或者点击 直链播放 并等待视频加载一会才能播放！或者在影片资源频道选择其他资源线路进行观看...1.扁平化、简洁风、多功能配置，优秀的电脑、平板、手机支持，响应式布局，不同设备不同展示效果...2.视频全自动采集，不需人工干预，懒人必备！</p></a>',
  'cebian2_ad' => '<a class="style02"  href="gm.php" target="_blank"><strong>本站同款</strong></br></br><img src="images/aly.jpg"></a>',
  'cebian3_ad' => '<a class="style03" href="http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=4bwF0c8YXDeo_uRfk03do2_6FhZmK7tw&authKey=P0I5XNiblqzBqXhE24K8S1NPiXf1r5hmllIII2%2FdvYlqSKMk2VV%2F1beXmcpECME1&noverify=0&group_code=865391384" target="_blank"><strong>多功能影院</strong><h2>看电影不卡顿</h2><img src="images/llq.png"></a>',
  'cebian4_ad' => '<a class="style04"><strong>官方提示</strong><h2>免费在线观看最新电影电视</h2><p>1.部分视频需要加载缓存一会才能播放！更多精彩分享请收藏官方发布链接地址...<p>2.观看视频：点击选择视频的列表名称进行播放！提示：如播放有问题请选择其他资源频道线路进行观看！或者添加官方QQ交流群以及微信号反馈</p></a></div>',
  'top_ad' => '<a href="app.php">APP下载</a>',
  'weixin_ad' => '<img src="images/qrcode.png">',
  'end_ad' => '<a href="app.php"><span><img src="images/gouwu.png"/>APP</span></a>',
  'dtk_ad' => '3600',
  'qq_name' => '醉玲珑#战狼#权力的游戏第七季',
  'hometopnotice' => '',
  'hometopright' => '',
  'homelink' => '',
  'sort' => '1,2,3,4,5,6,7,8,9,10',
  'joinhotkey' => '0',
);
?>