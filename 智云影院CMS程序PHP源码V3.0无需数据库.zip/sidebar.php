<div class="sidebar">
<div class="widget widget-textasst"><?php echo $aik['cebian1_ad'];?></div>
<div class="widget widget-textasst"><?php echo $aik['cebian2_ad'];?></div>
<div class="widget widget-textasst"><?php echo $aik['cebian3_ad'];?></div> 
<div class="widget widget-textasst"><?php echo $aik['cebian4_ad'];?></div>		
 </div>
		
		<script>
var ifh=$('.sidebar');
if(ifh.height()<10){
$('.content').css("width","100%");
}else{
}</script>